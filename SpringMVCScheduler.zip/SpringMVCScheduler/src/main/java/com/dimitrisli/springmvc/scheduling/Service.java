package com.dimitrisli.springmvc.scheduling;

public abstract interface Service {

	public abstract void performService();
}
